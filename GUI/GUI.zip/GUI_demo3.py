#wxPython 모듈을 불러옴
import wx

#TestFrame 클래스 선언, wx.Frame 값을 받음
class TestFrame(wx.Frame):
    #함수를 부르는 객체가 해당 클래스의 인스턴스인지 확인하기 위해 self를 첫 번째로 기입
    #set_info를 통해 값을 할당하지 않으면 get_info를 호출할 수 없는 오류를 줄이기 위해 인스턴스 생성시 변수값을 지정
    def __init__(self,parent,id,title):
        #Frame 앞에 wx는 모듈을 import 한 후 모듈 내부의 함수를 사용하는 방법이다.
        wx.Frame.__init__(self, parent, id, title, wx.DefaultPosition, wx.Size(400,500))
        # panel 생성
        panel = wx.Panel(self,-1,(0,0),(300,400), style=wx.SUNKEN_BORDER)
        # self.picture = 을 이용해 객체 내의 정보를 저장, 위에서 설정한 panel에 대한 정보가 wx 모듈 안의 StaticBitmap 함수로 들어간다.
        self.picture=wx.StaticBitmap(panel)
        panel.SetBackgroundColour(wx.WHITE)
        self.picture.SetFocus()
        self.picture.SetBitmap(wx.Bitmap('image/TEST1.bmp'))


'''
    def closeWindow(self, event):
        self.Close()

    def OnSelect(self,event):
        self.picture.SetFocus()
        self.picture.SetBitmap(wx.Bitmap('image/TEST1.bmp'))        
'''
#새로운 MyApp 클래스 선언, wx.App 값을 받음
class MyApp(wx.App):
    def OnInit(self):
        frame = TestFrame(None, -1, "TEST")
        frame.CenterOnScreen()

        StatusBar = frame.CreateStatusBar()
        StatusBar.SetStatusText('StatusBar')

        MenuBar = wx.MenuBar()
        menu = wx.Menu()
        menu.Append(wx.ID_EXIT, 'E&xit\tAlt-X', '종료')
        MenuBar.Append(menu, '&파일')

        menu1 = wx.Menu()
        menu1.Append(200, 'Test', '테스트메뉴')
        menu1.Append(201, 'Copy', '복사')
        menu1.Append(202, 'Paste', '붙여넣기')
        MenuBar.Append(menu1, '&편집')
        frame.SetMenuBar(MenuBar)

        frame.Show(True)
        return True

app = MyApp(0)
app.MainLoop()
